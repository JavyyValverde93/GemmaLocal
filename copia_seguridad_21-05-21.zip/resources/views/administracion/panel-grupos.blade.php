<x-menu-grupos>
    <x-slot name="slot">
        
    </x-slot>
</x-menu-grupos>