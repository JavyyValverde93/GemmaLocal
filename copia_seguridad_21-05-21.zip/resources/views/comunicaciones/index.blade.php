<x-menu-grupos>
    <x-slot name="slot">
		<div class="row migaspan">
            <a href="{{route('comunicaciones.index')}}" class="text-danger">Comunicaciones</a> >
        </div>
        <h5 align="center">Comunicaciones</h5>
        

</x-menu-grupos>